#include "widget.h"
#include <QtCharts/QChartView>
#include <QtCharts/QChart>
#include <QtCharts/QLegend>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QtCore/QRandomGenerator>
#include <QtWidgets/QGridLayout>
#include <QtCore/QTimer>

QT_CHARTS_USE_NAMESPACE

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
   // setMinimumSize(800, 600);
    setWindowTitle("Dartboard");
    //! [1]
    QChartView *chartView = new QChartView;
    chartView->setRenderHint(QPainter::Antialiasing);
    QChart *chart = chartView->chart();
    chart->legend()->setVisible(false);
    chart->setAnimationOptions(QChart::AllAnimations);
    //! [1]

    //! [2]
    qreal minSize = 0.1;
    qreal maxSize = 0.9;
    int donutCount = 5;
    //! [2]

    //! [3]
    for (int i = 0; i < donutCount; i++) {
        QPieSeries *donut = new QPieSeries;
        int sliceCount = 20;
        for (int j = 0; j < sliceCount; j++) {
            qreal value = 5;
            QPieSlice *slice = new QPieSlice(QString("%1").arg(value), value);  //new QPieSlice(QString("%1").arg(value), value)
            slice->setLabelVisible(false);
            slice->setLabelColor(Qt::white);
            slice->setLabelPosition(QPieSlice::LabelInsideTangential);
            connect(slice, &QPieSlice::clicked, this, &Widget::addScore);
            donut->append(slice);
            donut->setHoleSize(minSize + i * (maxSize - minSize) / donutCount);
            donut->setPieSize(minSize + (i + 1) * (maxSize - minSize) / donutCount);
            if((i%2) == 0)
            {
                slice->setColor(Qt::black);
            }
            else
            {
                slice->setColor(Qt::red);
            }
        }
        m_donuts.append(donut);
        chartView->chart()->addSeries(donut);
    }
    //! [3]

    //create inner bullseye
    QPieSeries *innerBullseye = new QPieSeries;
    int sliceCount = 1;
    int value = 50;
    QPieSlice *slice = new QPieSlice(QString("%1").arg(value), value);
    slice->setLabelVisible(false);
    slice->setLabelColor(Qt::white);
    slice->setLabelPosition(QPieSlice::LabelInsideHorizontal);
    connect(slice, &QPieSlice::clicked, this, &Widget::addScore);
    slice->setColor(Qt::black);
    innerBullseye->setHoleSize(0);
    innerBullseye->setPieSize(0.025);
    innerBullseye->append(slice);

    //create outer bullseye
    QPieSeries *outerBullseye = new QPieSeries;
    int outerValue = 25;
    QPieSlice *slice2 = new QPieSlice(QString("%1").arg(outerValue), outerValue);
    slice2->setLabelVisible(false);
    slice2->setLabelColor(Qt::white);
    slice2->setLabelPosition(QPieSlice::LabelInsideHorizontal);
    connect(slice2, &QPieSlice::clicked, this, &Widget::addScore);
    slice2->setColor(Qt::red);
    outerBullseye->setHoleSize(0.025);
    outerBullseye->setPieSize(0.10);
    outerBullseye->append(slice2);

    //add outer bullseye
    m_donuts.append(outerBullseye);
    chartView->chart()->addSeries(outerBullseye);
    //add inner bullseye
    m_donuts.append(innerBullseye);
    chartView->chart()->addSeries(innerBullseye);

    // create main layout
    //! [4]
    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(chartView, 1, 1);
    setLayout(mainLayout);
    //! [4]

    //! [5]
    //connect(updateTimer, &QTimer::timeout, this, &Widget::updateRotation);
    //! [5]
}

Widget::~Widget()
{

}

void Widget::addScore()
{
    QPieSlice *slice = qobject_cast<QPieSlice *>(sender());
    this->score = 0;
    this->score = slice->value();
    slice->setLabelVisible(true);
}
